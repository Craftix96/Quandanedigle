#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

int main(void) {

    MessageBeep(MB_ICONWARNING);

    MessageBox(0, "You got hacked by X-678_bb.exe!","X-678_bb.exe",0);

    return 0;
}