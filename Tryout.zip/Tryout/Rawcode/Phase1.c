#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include<conio.h>

int main() {
    
                                                                             
    printf(".\n\n                                                        uu$:$:$:$:$:$uu");
    printf(".\n                                                     uu$$$$$$$$$$$$$$$$$uu");
    printf(".\n                                                    u$$$$$$$$$$$$$$$$$$$$$u");
    printf(".\n                                                   u$$$$$$$$$$$$$$$$$$$$$$$u");
    printf(".\n                                                  u$$$$$$$$$$$$$$$$$$$$$$$$$u");
    printf(".\n                                                  u$$$$$$$$$$$$$$$$$$$$$$$$$u");
    printf(".\n                                                  u$$$$$$*   *$$$*   *$$$$$$u");
    printf(".\n                                                  *$$$$*      u$u      *$$$$*");
    printf(".\n                                                   $$$u       u$u       u$$$");
    printf(".\n                                                   $$$u      u$$$u      u$$$");
    printf(".\n                                                    *$$$$uu$$$   $$$uu$$$$*");
    printf(".\n                                                     *$$$$$$$*   *$$$$$$$*");
    printf(".\n                                                       u$$$$$$$u$$$$$$$u");
    printf(".\n                                                        u$*$*$*$*$*$*$u");
    printf(".\n                                            uuu         $$u$ $ $ $ $u$$         uuu");
    printf(".\n                                           u$$$$         $$u$u$u$u$u$$         $$$$u");
    printf(".\n                                            $$$$uu        *$$$$$$$$$*        uu$$$$");
    printf(".\n                                          u$$$$$$$$$$$      *******        uuuu$$$$$$");
    printf(".\n                                          SSSS***SSSSSSSSSuuu     uuuSSSSSSSSSSS***SSS*");
    printf(".\n                                           ***      **SSSSSSSSSSSSSSSSSSSS**      ***");
    printf(".\n                                                    uuuu **SSSSSSSSSSS**uuuu");
    printf(".\n                                            uSSSuuuSSSSSSSuu**     **uuSSSSSSuuuSSSu");
    printf(".\n                                            *SSSSSSSSSSSSS****     ****SSSSSSSSSSSS*");
    printf(".\n                                              *SSSSSSSSS*               *SSSSSSSS*");
    printf(".\n                                                SSS*                        *SSS");
    printf(".\n                                          ");
    printf(".\n                                                ");
    Sleep(2000);
    exit(0);
    
    return 0;
}
