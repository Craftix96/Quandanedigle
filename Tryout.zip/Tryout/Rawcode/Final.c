#include <stdio.h>
#include <stdlib.h>

int main() {

    system("C:\\Windows\\System32\\shutdown /s /t 20");

    return 0;
}